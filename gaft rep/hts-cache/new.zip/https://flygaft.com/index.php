
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    

    <!-- Open Graph -->
    <!-- This is facebooks default app ID, it stops facebook showing errors in the debugger below -->
    <meta property="fb:app_id" content="966242223397117" />
    <meta property="og:site_name" content="Gaft"/>
    <meta property="og:title" content="Home"/>
    <meta property="og:description" content=""/>
    <meta property="og:url" content="https://flygaft.com/"/>


    <meta name="twitter:card" content="summary" />
    <meta name="twitter:title" content="Gaft" />
    <meta name="twitter:description" content="" />
    <meta name="twitter:url" content="https://flygaft.com/" />
    

    
        <link href="https://fonts.googleapis.com/css2?family=Raleway&display=swap" rel="stylesheet"> 

    <link href="/application/themes/stux/css/vendor/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="/application/themes/stux/dist/css/style.css" rel="stylesheet" type="text/css" media="all">
    
<title>Home :: Gaft</title>

<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="generator" content="Concrete CMS"/>
<link rel="canonical" href="https://flygaft.com/">
<script type="text/javascript">
    var CCM_DISPATCHER_FILENAME = "/index.php";
    var CCM_CID = 1;
    var CCM_EDIT_MODE = false;
    var CCM_ARRANGE_MODE = false;
    var CCM_IMAGE_PATH = "/concrete/images";
    var CCM_APPLICATION_URL = "https://flygaft.com";
    var CCM_REL = "";
    var CCM_ACTIVE_LOCALE = "en_US";
</script>

<script type="text/javascript" src="/concrete/js/jquery.js?ccm_nocache=1d463a94354892a3be95dcca13f94abcbd2779b9"></script>
<link href="/concrete/css/features/navigation/frontend.css?ccm_nocache=1d463a94354892a3be95dcca13f94abcbd2779b9" rel="stylesheet" type="text/css" media="all">
<link href="/application/blocks/home_intro/view.css?ccm_nocache=1d463a94354892a3be95dcca13f94abcbd2779b9" rel="stylesheet" type="text/css" media="all">
<link href="/concrete/css/features/imagery/frontend.css?ccm_nocache=1d463a94354892a3be95dcca13f94abcbd2779b9" rel="stylesheet" type="text/css" media="all">

    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-PMZNRZB2RB"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-PMZNRZB2RB');
</script>
   <script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.7/ScrollMagic.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.7/plugins/debug.addIndicators.min.js"></script>
</head>
<body class="">
<div class=" ccm-page ccm-page-id-1 page-type-page-home page-template-page-home">

<div class="global-nav">
        <div class="container">
            <div class="row">
                
                <div class="col-sm-5 col-md-2 brand-logo-wrap">
                   
                    <a class="brand-logo" href="https://flygaft.com/"><img src="/application/themes/stux/img/gaft-logo-wit.svg" class="imgresponsive"></a>
                    <a class="brand-logo-color" href="https://flygaft.com/"><img src="/application/themes/stux/img/gaft-logo.svg" class="imgresponsive"></a>
                </div>
                <div class="col-sm-2 col-md-9 navbar-wrap">
                    <nav class="navbar">
                        
                        <button class="hamburger hamburger--collapse" type="button">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                        </button>
    
                            

    <ul class="nav"><li class=""><a href="https://flygaft.com/market-challenge" target="_self" class="">Market challenge</a></li><li class=""><a href="https://flygaft.com/our-solution" target="_self" class="">Our solution</a></li><li class=""><a href="https://flygaft.com/news-and-media" target="_self" class="">News &amp; Media</a></li><li class=""><a href="https://flygaft.com/about-us" target="_self" class="">About us</a></li><li class=""><a href="https://flygaft.com/Vacancies" target="_self" class="">Vacancies</a></li></ul>
 
                    </nav>
                </div>
                
                <div class="col-sm-5 col-md-1 headercontact-wrap"><a href="/contact" class="button headercontact">Contact</a></div>
            </div> <!-- \.row -->
        </div> <!-- \.container -->
    </div>
   
    

    


<section id="section-home-start" class="home-start-section"
    style="background-image:url(https://flygaft.com/application/files/cache/thumbnails/c49777cb19c7b3b2ef9a64c4c3a2d622.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="tekst">
                <img class="homeintrologo" src="/application/themes/stux/img/gaft-logo-wit.svg" class="imgresponsive">
                                    GAFT – Green Air Fuel Technology - enables the first end-to-end solution to sustainable aviation fuel out of carbon dioxide without fossil fuels
 <br><br><b>This is how:</b>                </div>
            
            </div>
        </div>
        
        
        </div>
        <!-- <div class="scroll-down">SCROLL<div class="arrow"></div>
        </div> -->
</section>
    <div class="scroll_indicator"></div>        
    <main class=""> 
   
    <div id="container">

      

    


<section id="section-671" class="panel film-blok-home fullscreen">

    
    <div class="container-absolute">
        <div class="content-wrap">
            <div class="kop">
                <span>Carbon Dioxide</span>            </div>
            <div class="tekst">
                                <p>We use carbon dioxide (CO<sub>2</sub>) as the sole carbon source which is recycled from our production process and complemented with CO<sub>2</sub> captured from the air or directly from environmentally friendly industries</p>
            </div>

        </div>
    </div>


    
    
        <video id="gaftMovie-id671" class="gaftMovie" width="100%" height="auto" preload="auto" muted
        playsinline="">
        <source src="/application/files/7516/4493/3669/CO2.mov" type="video/mp4">
        Your browser does not support HTML5 video.
    </video>
    
</section>

<script>
var ukeVid671 = document.getElementById('gaftMovie-id671');

// init controller
var controller671 = new ScrollMagic.Controller();

// build scene
var scene671 = new ScrollMagic.Scene({
        triggerElement: "#gaftMovie-id671",
        duration: "100%"
    })
    .addTo(controller671)
    //.addIndicators() // add indicators (requires plugin)

    .on("enter", function() {
        ukeVid671.play();
    })
    .on("leave", function() {
        ukeVid671.pause();
    })
</script>


    


<section id="section-673" class="panel film-blok-home tekst-links">

    
       
        <div class="content-wrap">
            <div class="kop">
                <span>Water</span>            </div>
            <div class="tekst">
                                <p>Water provides us with hydrogen that we use to supercharge CO<sub>2</sub> to a useful energy carrier</p>
            </div>

        </div>
    

    
    
        <video id="gaftMovie-id673" class="gaftMovie" width="100%" height="auto" preload="auto" muted
        playsinline="">
        <source src="/application/files/6016/4493/1016/water.mov" type="video/mp4">
        Your browser does not support HTML5 video.
    </video>
    
</section>

<script>
var ukeVid673 = document.getElementById('gaftMovie-id673');

// init controller
var controller673 = new ScrollMagic.Controller();

// build scene
var scene673 = new ScrollMagic.Scene({
        triggerElement: "#gaftMovie-id673",
        duration: "100%"
    })
    .addTo(controller673)
    //.addIndicators() // add indicators (requires plugin)

    .on("enter", function() {
        ukeVid673.play();
    })
    .on("leave", function() {
        ukeVid673.pause();
    })
</script>


    


<section id="section-675" class="panel film-blok-home fullscreen">

    
    <div class="container-absolute">
        <div class="content-wrap">
            <div class="kop">
                <span>Energy</span>            </div>
            <div class="tekst">
                                <p>We are committed to using 100% renewable electricity that we need to add hydrogen to CO<sub>2</sub></p>
            </div>

        </div>
    </div>


    
    
        <video id="gaftMovie-id675" class="gaftMovie" width="100%" height="auto" preload="auto" muted
        playsinline="">
        <source src="/application/files/2516/4493/1169/molens.mov" type="video/mp4">
        Your browser does not support HTML5 video.
    </video>
    
</section>

<script>
var ukeVid675 = document.getElementById('gaftMovie-id675');

// init controller
var controller675 = new ScrollMagic.Controller();

// build scene
var scene675 = new ScrollMagic.Scene({
        triggerElement: "#gaftMovie-id675",
        duration: "100%"
    })
    .addTo(controller675)
    //.addIndicators() // add indicators (requires plugin)

    .on("enter", function() {
        ukeVid675.play();
    })
    .on("leave", function() {
        ukeVid675.pause();
    })
</script>


    


<section id="section-619" class="panel film-blok-home tekst-links">

    
       
        <div class="content-wrap">
            <div class="kop">
                <span>Micro­organism</span>            </div>
            <div class="tekst">
                                <p>We harvest fatty acids out of our proprietary microorganisms that grow and multiply using our energy carrier</p>
            </div>

        </div>
    

    
    
        <video id="gaftMovie-id619" class="gaftMovie" width="100%" height="auto" preload="auto" muted
        playsinline="">
        <source src="/application/files/9716/4493/0862/microben.mov" type="video/mp4">
        Your browser does not support HTML5 video.
    </video>
    
</section>

<script>
var ukeVid619 = document.getElementById('gaftMovie-id619');

// init controller
var controller619 = new ScrollMagic.Controller();

// build scene
var scene619 = new ScrollMagic.Scene({
        triggerElement: "#gaftMovie-id619",
        duration: "100%"
    })
    .addTo(controller619)
    //.addIndicators() // add indicators (requires plugin)

    .on("enter", function() {
        ukeVid619.play();
    })
    .on("leave", function() {
        ukeVid619.pause();
    })
</script>


    


<section id="section-677" class="panel film-blok-home fullscreen">

    
    <div class="container-absolute">
        <div class="content-wrap">
            <div class="kop">
                <span>Jetfuel</span>            </div>
            <div class="tekst">
                                <p style="color:#000000">Fatty acids are the most used feedstock to make biofuels. There is a growing global shortage of these fats that are currently only derived from food production processes. We provide the producers of sustainable aviation fuel with an economical alternative feedstock that has no fossil fuel or food origin.</p>

<p><span class="button btn-primary"><a href="/contact?msg=Dear Frank, Please send me the GAFT quality specification. Regards,">Request quality specification</a></span></p>
            </div>

        </div>
    </div>


    
    
        <video id="gaftMovie-id677" class="gaftMovie" width="100%" height="auto" preload="auto" muted
        playsinline="">
        <source src="/application/files/4016/4493/1264/vliegtuig.mov" type="video/mp4">
        Your browser does not support HTML5 video.
    </video>
    
</section>

<script>
var ukeVid677 = document.getElementById('gaftMovie-id677');

// init controller
var controller677 = new ScrollMagic.Controller();

// build scene
var scene677 = new ScrollMagic.Scene({
        triggerElement: "#gaftMovie-id677",
        duration: "100%"
    })
    .addTo(controller677)
    //.addIndicators() // add indicators (requires plugin)

    .on("enter", function() {
        ukeVid677.play();
    })
    .on("leave", function() {
        ukeVid677.pause();
    })
</script>

</div>
<div class="section_nav" id="section_nav">
<a class="section-nav-link" id="link_671" href="#section-671">Carbon Dioxide</a><a class="section-nav-link" id="link_673" href="#section-673">Water</a><a class="section-nav-link" id="link_675" href="#section-675">Energy</a><a class="section-nav-link" id="link_619" href="#section-619">Micro­organism</a><a class="section-nav-link" id="link_677" href="#section-677">Jetfuel</a></div>

        
    </main>
    <footer class="container-fluid mrgn-t gradient-footer-back pdng-t">
        <div class="container">
            <div class="row">
                    
                    <div class="col-md-6">
                    <a class="brand-logo-color" href="https://flygaft.com/"><img src="/application/themes/stux/img/gaft-logo.svg" class="imgresponsive-60 footer-logo"></a>
                    </div>
                    <div class="col-md-3 footermenu">
                    

    <h4><strong>Navigate</strong></h4>



    <ul class="nav"><li class=""><a href="https://flygaft.com/market-challenge" target="_self" class="">Market challenge</a></li><li class=""><a href="https://flygaft.com/our-solution" target="_self" class="">Our solution</a></li><li class=""><a href="https://flygaft.com/news-and-media" target="_self" class="">News &amp; Media</a></li><li class=""><a href="https://flygaft.com/about-us" target="_self" class="">About us</a></li><li class=""><a href="https://flygaft.com/Vacancies" target="_self" class="">Vacancies</a></li></ul>
                    </div>
                    <div class="col-md-3">

    <h4><strong>Contact us</strong></h4>



    <p>+31 6 1136 1442<br />
<a href="mailto:frank.schreurs@flygaft.com">frank.schreurs@flygaft.com</a></p>

                    </div>
                    
            </div>
        </div>
        <div class="container-fluid gradient-back footer-bottom">
            <div class="container h-100">
            <div class="row h-100">
            
                    
                    <div class="col-md-6 align-vert">
                    <div>© 2025 GAFT  All Rights Reserved</div>
                        
                    </div>
                    <div class="col-md-3 align-vert"><a href="https://studio-ux.nl" class="footer-link">Site by studio-ux</a>
                    <!--  -->
                    </div>
                    <div class="col-md-3 align-vert">
                    <!--  -->
                    </div>
            </div>
            </div>
    </footer>

</div> 


<script type="text/javascript" src="/application/themes/stux/js/main.js?ccm_nocache=1d463a94354892a3be95dcca13f94abcbd2779b9"></script>
<script type="text/javascript" src="/concrete/js/features/navigation/frontend.js?ccm_nocache=1d463a94354892a3be95dcca13f94abcbd2779b9"></script>
<script type="text/javascript" src="/concrete/js/features/imagery/frontend.js?ccm_nocache=1d463a94354892a3be95dcca13f94abcbd2779b9"></script>

</body>
</html>